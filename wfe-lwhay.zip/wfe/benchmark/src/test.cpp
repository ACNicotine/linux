//
// Created by iclab on 4/8/21.
//

#include <list>
#include <vector>
#include <iostream>
#include <thread>
#include <atomic>

using namespace std;

const size_t cacheLimit = 100;

struct CircleQueue {
    uint64_t cache[cacheLimit];
    size_t head = 0, tail = 0;
public:
    bool push(uint64_t e) {
        if ((tail + 1) % cacheLimit == head) return false;
        cache[tail] = e;
        tail = (tail + 1) % cacheLimit;
        return true;
    }

    uint64_t pop() {
        if (head == tail) return -1;
        uint64_t cur = cache[head];
        head = (head + 1) % cacheLimit;
        return cur;
    }

    size_t size() {
        return (tail + cacheLimit - head) % cacheLimit;
    }
};

class MultithreadData {
public:
    atomic<size_t> tick{0};
public:
    MultithreadData() {}

    ~MultithreadData() {}

    void printTick() { std::cout << tick << std::endl; }
};

void queueTest() {
    CircleQueue queue;
    cout << queue.pop() << endl;
    for (int i = 0; i < 100; i++) {
        cout << queue.push(i) << " ";
        if ((i + 1) % 25 == 0) cout << endl;
    }
    for (int i = 0; i < 100; i++) {
        cout << queue.pop() << " ";
        if ((i + 1) % 25 == 0) cout << endl;
    }

}

void structTest() {
    bool reEnter[323] = {0};
    for (int i = 0; i < 323; i++) cout << reEnter[i] << "-";
    cout << endl;
    list<int> myTrash = {1, 2, 3, 4, 5, 6, 7, 8, 9};

    for (typename std::list<int>::iterator iterator = myTrash.begin(), end = myTrash.end(); iterator != end;) {
        cout << *iterator++ << endl;
    }
    cout << "****************************************************************************" << endl;

    list<int>::const_iterator stop = myTrash.cend();
    int count = 0, total = myTrash.size();
    for (list<int>::iterator iterator = myTrash.begin(); /*iterator != stop && count < 100*/
         count < total; count++) {
        cout << *iterator << " " << *stop << " " << &(*iterator) << " " << &(*stop) << " ( ";
        list<int>::iterator current = iterator;
        iterator = myTrash.erase(iterator);
        if (*current % 2 == 0) {
            // list<int>::iterator curiter = iterator;
            cout << *iterator << "*";
            myTrash.push_back(*current);
            // iterator = myTrash.erase(iterator);
            cout << *iterator << " ) " << " ";
            // stop--;
        } else {
            cout << *iterator << " ";
            /*if (iterator != stop)*/ // iterator++;
            cout << *iterator << " ) " << " ";
        }
        cout << " |||| ";
        for (typename std::list<int>::iterator iter = myTrash.begin(), end = myTrash.end(); iter != end;) {
            cout << *iter++ << " ";
        }
        cout << endl;
    }
    cout << "****************************************************************************" << endl;

    for (typename std::list<int>::iterator iterator = myTrash.begin(), end = myTrash.end(); iterator != end;) {
        cout << *iterator++ << endl;
    }
    cout << "****************************************************************************" << endl;
}

thread_local atomic<size_t> ltick{0};

int main() {
    queueTest();
    structTest();
    MultithreadData md;

    vector<thread> workers;
    for (int i = 0; i < 4; i++)
        workers.push_back(thread([](MultithreadData &mdr/*, atomic<size_t> &ltick*/) {
            ltick = 0;
            for (int i = 0; i < 10000000; i++) {
                mdr.tick.fetch_add(1);
                ltick++;
            }
        }, ref(md)/*, ref(ltick)*/));

    for (int i = 0; i < 4; i++) {
        cout << ltick << endl;
        workers[i].join();
    }
    md.printTick();
    int total = (ulong) (1llu << 31);
    cout << total << endl;

    return 0;
}