
#ifndef BROWN_TRACKER_HPP
#define BROWN_TRACKER_HPP

#ifndef _REENTRANT
#define _REENTRANT
#endif

#include <atomic>
#include <cassert>
#include "brown/pool_none.h"
#include "brown/allocator_new.h"
#include "brown/pool_perthread_and_shared.h"
#include "brown/record_manager.h"
#include "brown/reclaimer_hazardptr.h"
#include "brown/reclaimer_ebr_token.h"
#include "brown/reclaimer_ebr_tree.h"
#include "brown/reclaimer_ebr_tree_q.h"
#include "brown/reclaimer_debra.h"
#include "brown/reclaimer_debraplus.h"
#include "brown/reclaimer_debracap.h"
#include "brown/reclaimer_batchhp.h"

#include "BaseTracker.hpp"

static thread_local uint64_t holder{0};
static int free_type = -1; // 0: hazard; 1: debra; 2: others

template<class T, class D = T, class N = allocator_new<T>, class P = pool_perthread_and_shared<T>, class R = reclaimer_ebr_token<T, P>>
class BrownTracker : public BaseTracker<T> {
    typedef typename N::template rebind<D>::other Allocator;
    typedef typename P::template rebind2<D, Allocator>::other Pool;
    typedef typename R::template rebind2<D, Pool>::other Reclaimer;
private:
    size_t thread_num;
    Allocator *allocator;
    Pool *pool;
    Reclaimer *reclaimer;
    bool *hasInitialized;
//	int task_num;
//	int slotsPerThread;
//	int freq;
//	bool collect;
//
//	RAllocator* mem;
//
//	paddedAtomic<T*>* slots;
//	padded<int>* cntrs;
//	padded<std::list<T*>>* retired; // TODO: use different structure to prevent malloc locking....
//
//	void empty(int tid){
//		std::list<T*>* myTrash = &(retired[tid].ui);
//		for (typename std::list<T*>::iterator iterator = myTrash->begin(), end = myTrash->end(); iterator != end; ) {
//			auto ptr = *iterator;
//			bool danger = !ptr->deletable();
//			if (!danger){
//			for (int i = 0; i<task_num*slotsPerThread; i++){
//				if(ptr == slots[i].ui){
//					danger = true;
//					break;
//				}
//			}
//			}
//			if(!danger){
//				this->reclaim(ptr);
//				this->dec_retired(tid);
//				iterator = myTrash->erase(iterator);
//			}
//			else{++iterator;}
//		}
//		return;
//	}

public:
    ~BrownTracker() {
        for (int tid = 0; tid < thread_num; tid++) {
            if (!hasInitialized[tid]) continue;
            reclaimer->deinitThread(tid);
            allocator->deinitThread(tid);
        }
        delete reclaimer;
        //delete pool;
        delete allocator;
    }

    BrownTracker(int task_num, int slotsPerThread, int emptyFreq, bool collect) : BaseTracker<T>(task_num),
                                                                                  thread_num(task_num) {
        std::cout << typeid(reclaimer).name() << std::endl;
        hasInitialized = new bool[task_num];
        for (int i = 0; i < task_num; i++) hasInitialized[i] = false;
        allocator = new Allocator(thread_num, nullptr);
        pool = new Pool(thread_num, allocator, nullptr);
        reclaimer = new Reclaimer(thread_num, pool, nullptr);
        if (typeid(R) == typeid(reclaimer_hazardptr<>)) free_type = 0;
        else if (typeid(R) == typeid(reclaimer_debra<>)) free_type = 1;
        else free_type = 2;
    }

    void *alloc(int tid) {
        return (void *) (pool->get(tid));
    }

    void retire(T *ptr, int tid) {
        if (!hasInitialized[tid]) {
            allocator->initThread(tid);
            reclaimer->initThread(tid);
            hasInitialized[tid] = true;
        }
        reclaimer->retire(tid, ptr);
        if (free_type != 0) {
            /*reclaimer->template startOp<T>(tid, (void *const *const) &reclaimer, 1);
            reclaimer->endOp(tid);*/
            // reclaimer->rotateEpochBags(tid);
        }
    }

    T *read(std::atomic<T *> &obj, int idx, int tid, T *node) {
        if (!hasInitialized[tid]) {
            allocator->initThread(tid);
            reclaimer->initThread(tid);
            hasInitialized[tid] = true;
        }
        if (free_type == 0) {
            uint64_t address = 0;
            T *par_ptr = obj.load(std::memory_order_relaxed);
            do {
                if (address != 0) reclaimer->unprotect(tid, (D *) address);
                address = ((uint64_t) (obj.load(std::memory_order_relaxed))) & 0xfffffffffffffffc;
                if (address == 0) break;
                reclaimer->protect(tid, (D *) address, callbackReturnTrue, nullptr, false);
                par_ptr = obj.load(std::memory_order_relaxed);
            } while (address != ((uint64_t) par_ptr & 0xfffffffffffffffc));
            holder = address;
            return par_ptr;
        } else {
            T *entry = obj.load(std::memory_order_relaxed);
            holder = (uint64_t) entry & 0xfffffffffffffffc;
            if (holder == 0) return entry;
            //std::cout << "start: " << tid << " " << address << std::endl;
            // we can try this for higher performance.
            /*reclaimer->template startOp<T>(tid, (void *const *const) &reclaimer, 1);*/
            return obj.load(std::memory_order_relaxed);
        }
    }

    void start_op(int tid) {
        if (!hasInitialized[tid]) {
            allocator->initThread(tid);
            reclaimer->initThread(tid);
            hasInitialized[tid] = true;
        }
        if (free_type != 0) reclaimer->template startOp<T>(tid, (void *const *const) &reclaimer, 1);
    }

    void end_op(int tid) {
        if (free_type != 0) reclaimer->endOp(tid);
    }

    void clearAll(int tid) {
        /*if (holder != 0) {
            if (free_type == 0) {
                reclaimer->unprotect(tid, (D *) holder);
            } else {
                reclaimer->endOp(tid);
                holder = 0;
            }
        }
        if (free_type != 0) reclaimer->rotateEpochBags(tid);*/
    }

    void clear_all(int tid) {
        clearAll(tid);
    }

//	~HazardTracker(){};
//	HazardTracker(int task_num, int slotsPerThread, int emptyFreq, bool collect):BaseTracker<T>(task_num){
//		this->task_num = task_num;
//		this->slotsPerThread = slotsPerThread;
//		this->freq = emptyFreq;
//		slots = new paddedAtomic<T*>[task_num*slotsPerThread];
//		for (int i = 0; i<task_num*slotsPerThread; i++){
//			slots[i]=NULL;
//		}
//		retired = new padded<std::list<T*>>[task_num];
//		cntrs = new padded<int>[task_num];
//		for (int i = 0; i<task_num; i++){
//			cntrs[i]=0;
//			retired[i].ui = std::list<T*>();
//		}
//		this->collect = collect;
//	}
//	HazardTracker(int task_num, int slotsPerThread, int emptyFreq):
//		HazardTracker(task_num, slotsPerThread, emptyFreq, true){}
//
//	T* read(std::atomic<T*>& obj, int idx, int tid, T* node){
//		T* ret;
//		T* realptr;
//		while(true){
//			ret = obj.load(std::memory_order_acquire);
//			realptr = (T*)((size_t)ret & 0xfffffffffffffffc);
//			reserve_slot(realptr, idx, tid);
//			if(ret == obj.load(std::memory_order_acquire)){
//				return ret;
//			}
//		}
//	}
//
//	void reserve_slot(T* ptr, int slot, int tid){
//		slots[tid*slotsPerThread+slot] = ptr;
//	}
//	void reserve_slot(T* ptr, int slot, int tid, T* node){
//		slots[tid*slotsPerThread+slot] = ptr;
//	}
//	void clearSlot(int slot, int tid){
//		slots[tid*slotsPerThread+slot] = NULL;
//	}
//	void clearAll(int tid){
//		for(int i = 0; i<slotsPerThread; i++){
//			slots[tid*slotsPerThread+i] = NULL;
//		}
//	}
//	void clear_all(int tid){
//		clearAll(tid);
//	}
//
//	void retire(T* ptr, int tid){
//		if(ptr==NULL){return;}
//		std::list<T*>* myTrash = &(retired[tid].ui);
//		// for(auto it = myTrash->begin(); it!=myTrash->end(); it++){
//		// 	assert(*it !=ptr && "double retire error");
//		// }
//		myTrash->push_back(ptr);
//		if(collect && cntrs[tid]==freq){
//			cntrs[tid]=0;
//			empty(tid);
//		}
//		cntrs[tid].ui++;
//	}
//
//
//	bool collecting(){return collect;}

};


#endif
