//
// Created by iclab on 4/3/21.
//

#ifndef WFE_LISTHEAP_H
#define WFE_LISTHEAP_H

#ifdef NGC
#define COLLECT false
#else
#define COLLECT true
#endif

#define DEALY_PERIOD (0)

thread_local void **listNodes;
thread_local std::atomic<size_t> rc{0};
thread_local std::atomic<size_t> wc{0};
thread_local bool initialized = false;
//thread_local std::atomic<bool> locked{false};

template<class K, class V>
class ListHeap : public RUnorderedMap<K, V>, public RetiredMonitorable {
private:
    size_t idxSize;

    std::hash<K> hasher;

    struct Node {
        V value;

        Node() {}

        Node(V v) : value{v} {}

        inline bool deletable() { return true; }
    };

    MemoryTracker<Node> *memory_tracker;

    std::list<Node *> cachedLists[MAX_DEFAULT_THREAD_NUMBER];


public:
    ListHeap(GlobalTestConfig *gtc, int idx_size) : RetiredMonitorable(gtc), idxSize(idx_size) {
        int epochf = gtc->getEnv("epochf").empty() ? 150 : stoi(gtc->getEnv("epochf"));
        int emptyf = gtc->getEnv("emptyf").empty() ? 30 : stoi(gtc->getEnv("emptyf"));
        std::cout << "emptyf:" << emptyf << std::endl;
        memory_tracker = new MemoryTracker<Node>(gtc, epochf, emptyf, 3, COLLECT);
    }

    ~ListHeap() {
        std::cout << "****************" << rc << " " << wc << std::endl;
    };

    void init(int tid) {
        if (!initialized) {
            listNodes = (void **) (new Node *[idxSize]);
            for (size_t i = 0; i < idxSize; i++) {
                void *ptr = memory_tracker->alloc(tid);
                listNodes[i] = new(ptr) Node();
            }
            initialized = true;
        }
    }

    optional<V> get(K key, int tid) {
        init(tid);
        memory_tracker->start_op(tid);

        size_t idx = hasher(key) % idxSize;
        Node *node = ((Node *) listNodes[idx]);
        for (int i = 0; i < DEALY_PERIOD; i++) rc.fetch_add(1);

        memory_tracker->end_op(tid);
        return node->value;
    }

    optional<V> put(K key, V val, int tid) {
        init(tid);
        memory_tracker->start_op(tid);

        size_t idx = hasher(key) % idxSize;
        Node *old = (Node *) (listNodes[idx]);
        Node *ptr = (Node *) (memory_tracker->alloc(tid));
        Node *node = new(ptr) Node();
        node->value = val;
        listNodes[idx] = node;
        if (old != nullptr) {
#if LAZY_RETIRE
            cachedLists[tid].push_back(old);
#else
            memory_tracker->retire(old, tid);
#endif
            for (int i = 0; i < DEALY_PERIOD * 10; i++) wc.fetch_add(1);
            //memory_tracker->reclaim(old, tid);
        }

#if LAZY_RETIRE
        for (typename std::list<Node *>::iterator iter = cachedLists->begin(); iter != cachedLists->end(); iter++)
            memory_tracker->retire(*iter, tid);
        cachedLists->clear();
#endif
        memory_tracker->end_op(tid);
        return val;
    }

    bool insert(K key, V val, int tid) { put(key, val, tid); }

    optional<V> remove(K key, int tid) {
        /*bool isLocked = locked.load();
        while (isLocked) {
            locked.compare_exchange_strong(isLocked, true);
        };*/
        init(tid);
        memory_tracker->start_op(tid);

        size_t idx = hasher(key) % idxSize;
        Node *node = (Node *) (listNodes[idx]);
        V val = node->value;
        listNodes[idx] = nullptr;
        if (node != nullptr) {
#if LAZY_RETIRE
            cachedLists[tid].push_back(node);
#else
            memory_tracker->retire(node, tid);
#endif
            for (int i = 0; i < DEALY_PERIOD * 10; i++) wc.fetch_add(1);
            //memory_tracker->reclaim(old, tid);
        }
        Node *ptr = (Node *) (memory_tracker->alloc(tid));
        node = new(ptr) Node();
        node->value = val;
        listNodes[idx] = node;

#if LAZY_RETIRE
        for (typename std::list<Node *>::iterator iter = cachedLists->begin(); iter != cachedLists->end(); iter++)
            memory_tracker->retire(*iter, tid);
        cachedLists->clear();
#endif
        memory_tracker->end_op(tid);
        /*locked.store(false);*/
        return val;
    }

    optional<V> replace(K key, V val, int tid) { put(key, val, tid); }
};


template<class K, class V>
class ListHeapFactory : public RideableFactory {
    ListHeap<K, V> *build(GlobalTestConfig *gtc) {
        return new ListHeap<K, V>(gtc, 30000);
    }
};

#endif //WFE_LISTHEAP_H
